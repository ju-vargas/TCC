# pacote_servidor_2023

Pacote para rodar o Vivado e a potencia das versoes sistolicas no servidor,
que so tem o Vivado/Vitis 2023.2. Montado em 2026-10-30. Substitui o
pacote_servidor_sistolico, que precisa do Vitis 2026.1 no servidor.

A parte do HLS foi feita aqui, com o Vitis 2026.1 (o mesmo das outras
versoes): o RTL e os vetores de teste de cada cenario ja vem prontos. No
servidor rodam so o Vivado e o xsim.

| Versao | Para que | Vias | Matrizes por cenario |
|---|---|---|---|
| 455 | calibracao (ja tem resultados com o Vivado 2026.1) | 8 | 48 |
| 152_sistolico | alvo TDLA30-300, 152 ciclos | 2 | 96 |
| 114_sistolico | alvo TDLB100-400, 114 ciclos | 4 | 96 |

O testbench inverte lotes inteiros (pelo menos 3), entao o numero de
matrizes passa das 20 da lista de cada cenario.

## Como rodar

    tar xzf pacote_servidor_2023.tar.gz
    cd pacote_servidor_2023
    module load vivado/2023.2-enterprise
    ./rodar.sh todas

Ou uma versao e uma etapa por vez (NUCLEOS e opcional, usa o taskset):

    NUCLEOS=0-7 ./rodar.sh 455 vivado
    ./rodar.sh 455 potencia

Ordem sugerida: primeiro a 455 completa. Se ela der certo, a 152 e depois a
114 (a maior).

| Etapa | O que faz | Resultado |
|---|---|---|
| vivado | sintese RTL e implementacao fora de contexto, 100 MHz (vivado.tcl) | versoes/<v>/trabalho/vivado/resumo.txt |
| potencia | simulacao da netlist roteada com SAIF, confere a saida com a do C, report_power, nos 5 cenarios (potencia.py) | versoes/<v>/trabalho/potencia/potencia.csv |

- Cada etapa que termina bem grava versoes/<v>/trabalho/<etapa>/FEITO, e a
  proxima chamada pula essa etapa. Para refazer, apagar esse FEITO.
- Se uma etapa falha, o rodar.sh para naquela versao e passa para a
  seguinte. O andamento fica em rodar.log; o log do Vivado em
  versoes/<v>/trabalho/vivado/log.txt.
- Se a netlist der uma inversa diferente da do C, a etapa potencia para com
  "as inversas da netlist diferem das do C".

## O que tem aqui

- versoes/<v>/rtl/: o RTL que o HLS 2026.1 gerou (syn/verilog), igual
  arquivo por arquivo ao das sinteses ja feitas nas pastas
  hardware/cholesky_hardware_diretivas_<v>/, mais o xdc (relogio de 10 ns).
- versoes/<v>/sim/: o testbench da co-simulacao do HLS, sem o RTL. O
  potencia.py poe a netlist roteada no lugar dele.
- versoes/<v>/cenarios/<cenario>/: os vetores de entrada e as inversas do C
  (tv/cdatafile) e o numero de matrizes. Sao as mesmas 20 matrizes por
  cenario da referencia.
- vivado.tcl, potencia.py, resumo_vivado.py, rodar.sh: os scripts.
- O pacote foi montado por hardware/montar_pacote_2023.py.

## Calibracao com a 455

A 455 roda no servidor com os mesmos scripts das sistolicas. Comparando com
os resultados dela feitos aqui, da para ver quanto a versao do Vivado muda
os numeros. Resultados da 455 aqui (Vivado 2026.1, fluxo do HLS):

| | LUT | FF | DSP | BRAM (blocos de 36 kb) | URAM | Caminho critico |
|---|---|---|---|---|---|---|
| 455, 2026.1 | 55.448 | 44.110 | 456 | 120 | 0 | 9,169 ns |

Duas diferencas entre o fluxo daqui e o do servidor:

1. A versao do Vivado (2026.1 aqui, 2023.2 no servidor).
2. O topo. O HLS poe o inversor dentro de um block design (bd_0_wrapper).
   O vivado.tcl sintetiza o cholesky_inverse direto. As opcoes sao as mesmas
   do script que o HLS gerou: synth_design -directive
   sdx_optimization_effort_high -mode out_of_context, e opt_design,
   place_design, phys_opt_design e route_design com as opcoes padrao.

Para separar as duas diferencas, o vivado.tcl tambem rodou aqui, com o
Vivado 2026.1 (2026-10-30). No servidor, rodou com o 2023.2 (17 min):

| 455 | LUT | FF | DSP | BRAM | URAM | Caminho critico |
|---|---|---|---|---|---|---|
| 2026.1, fluxo do HLS | 55.448 | 44.110 | 456 | 120 | 0 | 9,169 ns |
| 2026.1, vivado.tcl | 55.453 | 44.110 | 456 | 120 | 0 | 9,269 ns |
| 2023.2, vivado.tcl (servidor) | 55.482 | 44.110 | 456 | 120 | 0 | 8,948 ns |

FF, DSP, BRAM e URAM iguais nos tres. LUT muda menos de 0,1%. O caminho
critico varia entre 8,9 e 9,3 ns, e os tres atendem os 10 ns. Aqui, o
vivado.tcl teve pico de 7,1 GB de memoria (route_design) e levou cerca de
28 min (dividindo os nucleos com outras simulacoes).

## O que foi conferido aqui

- RTL de cada versao igual, arquivo por arquivo, ao da sintese ja feita na
  pasta da versao (montar_pacote_2023.py confere).
- vivado.tcl na 455, com o Vivado 2026.1 (tabela acima).
- potencia.py com a netlist roteada da 455 (fluxo do HLS), xsim 2026.1,
  TDLA30-5: o testbench sem o RTL elabora com as bibliotecas reduzidas, e a
  inversa da netlist sai igual a do C.
- Gravacao do SAIF escopo por escopo, na 4545 (TDLB100-400): mesma potencia
  do SAIF antigo (2,521 W total, 0,304 W dinamica) e inversa igual a do C.
  Com current_scope, casam 115.449 de 115.449 redes, como no SAIF antigo
  (conferido com uma simulacao curta, de 2 us).
- Nao testados aqui: o POST_SYN (so as sistolicas tem o verificador de
  dependencias, e nao ha netlist delas aqui) e o read_saif com o caminho de
  dois niveis sobre o roteado.dcp do vivado.tcl.

## Resultados do Vivado no servidor (2026-10-30)

| Versao | LUT | FF | DSP | BRAM (blocos de 36 kb) | URAM | Caminho critico | Tempo | Pico de memoria |
|---|---|---|---|---|---|---|---|---|
| 455 | 55.482 | 44.110 | 456 | 120 | 0 | 8,948 ns | 17 min | |
| 152_sistolico | 154.016 | 103.627 | 1.700 | 463 | 0 | 8,820 ns | 50 min | 9,9 GB |
| 114_sistolico | 372.697 | 234.826 | 3.400 | 266 | 0 | 9,742 ns | 1 h 54 min | 15,8 GB |

Relatorios em ../resultados_servidor/. A memoria ficou bem abaixo da
estimativa da secao seguinte (cerca de 20 GB na 152 e 40 GB na 114).

## Memoria (estimativa feita antes de rodar, sem fonte)

Aqui, na 455, o Vivado do HLS teve picos de 6,0 GB na sintese RTL e 7,1 GB
na implementacao (logs do synth_1 e do impl_1). O vivado.tcl roda tudo num
processo so. A 152 tem cerca de 2,7 vezes mais LUT que a 455 e a 114 cerca de
6 vezes (estimativa do HLS), entao a memoria deve crescer junto. Vale rodar
uma versao de cada vez.
