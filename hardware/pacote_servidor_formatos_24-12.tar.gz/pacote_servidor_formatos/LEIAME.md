# pacote_servidor_formatos

Pacote para rodar o Vivado e a potencia de todas as arquiteturas, nos 5
formatos, no servidor (Vivado 2023.2). Montado a partir de 2026-10-31 por
../montar_pacote_formatos.py. Mesmo fluxo do ../pacote_servidor_2023/ (ver o
LEIAME.md dele): o HLS 2026.1 roda aqui, e o servidor roda so o Vivado e o
xsim.

## O que entra

Formatos (16 x 16):

| Formato | Modo |
|---|---|
| <24,12> | RND_ZERO/WRAP (estudo principal, primeiro na fila) |
| <22,12> | RND_ZERO/WRAP |
| <28,14> | RND_ZERO/WRAP |
| <26,12> | RND_ZERO/WRAP |
| <30,14> | TRN/SAT |

Arquiteturas, com o cenario da potencia:

| Arquitetura | Pasta | Cenario |
|---|---|---|
| sem_otimizacao | ../cholesky_hardware (sem diretivas de ciclo) | os 5 |
| 9090 | ../cholesky_hardware_diretivas | TDLA30-5 |
| 4545 | ../cholesky_hardware_diretivas_4545 | TDLA30-10 (matrizes do TDLA30-5) |
| 606 | ../cholesky_hardware_diretivas_606 | TDLA30-75 |
| 152_sistolico | ../cholesky_hardware_diretivas_152_sistolico | TDLA30-300 |
| 455 | ../cholesky_hardware_diretivas_455 | TDLC300-100 |
| 114_sistolico | ../cholesky_hardware_diretivas_114_sistolico | TDLB100-400 |

- O TDLA30-10 usa as mesmas matrizes do TDLA30-5: mesmo N (192) e mesma
  portadora (3,5 GHz) (../testes/AMOSTRAGEM.md, tabela das pastas).
- Por ultimo, a versao sem otimizacao em 32 x 32, nos 5 formatos.
- <24,12> 152_sistolico e 114_sistolico ficam de fora: ja rodaram com o
  ../pacote_servidor_2023/.
- Nome de cada versao: <formato>_<arquitetura>[_32x32], em versoes/.
  fila.txt tem a ordem.

Antes de entrar no pacote, cada versao passa por:
1. Sintese C. Se a estimativa do HLS passar de 5.952 DSP ou de 90% dos
   871.680 LUT da XCU50, fica de fora (viabilidade.csv, "nao cabe"). O DSP
   do HLS bateu com o do Vivado nas 6 arquiteturas em <24,12>; no LUT, o
   Vivado deu ate 7,8% acima (LEIAME do pacote_servidor_2023).
2. RTL igual ao de uma sintese ja feita com os mesmos fontes e o mesmo
   syn.cflags, quando existe (<24,12> e a versao sem otimizacao em <22,12>,
   <24,12> e <28,14>).
3. <26,12> e <30,14> nas arquiteturas otimizadas: so com a conferencia bit a
   bit sem diferencas (../conferir_formatos_novos.sh). Senao, "sem
   conferencia bit a bit" no viabilidade.csv.

## Como rodar

Copiar para uma pasta NOVA no servidor (nao em cima do pacote_servidor_2023,
que pode estar rodando):

    tar xzf pacote_servidor_formatos.tar.gz
    cd pacote_servidor_formatos
    module load vivado/2023.2-enterprise
    nohup ./rodar.sh todas > /dev/null 2>&1 &

- JOBS versoes rodam ao mesmo tempo (padrao 4). Ex.: `JOBS=6 ./rodar.sh todas`.
- Uma versao ou uma etapa: `./rodar.sh 24-12_9090 -- vivado`.
- Andamento em rodar.log. Cada etapa que termina grava FEITO e e pulada na
  proxima chamada; uma versao que falha nao para as outras.
- Resultados: versoes/<v>/trabalho/vivado/resumo.txt e
  versoes/<v>/trabalho/potencia/potencia.csv.

## Quantos trabalhos ao mesmo tempo

Servidor em 2026-10-31: 64 vCPUs, 188 GB (70 GB disponiveis), 7 usuarios,
carga perto de 6, swap cheio.

- Um Vivado ja usa o maximo de threads: o log diz "a maximum of 8 CPUs" no
  place e no phys_opt, e 8 e o limite do general.maxThreads no 2023.2
  (UG904 2023.2, "Multithreading with the Vivado Tools"). A sintese RTL
  pede 4 processos (UG901 2023.2), mas nos logs o tempo de CPU ficou igual
  ao tempo real (15:16 contra 15:33 na 152): roda praticamente serial.
- O xsim: o -mt do xelab paraleliza so a compilacao (UG900). Para a
  simulacao em si, sem fonte.
- Por isso o ganho vem de rodar varias versoes juntas (JOBS). Com 4: ate 32
  threads e, pelo pico da 114 em <24,12> (16 GB), uns 40 a 50 GB no pior
  caso (estimativa minha). Formatos maiores devem usar mais memoria.
