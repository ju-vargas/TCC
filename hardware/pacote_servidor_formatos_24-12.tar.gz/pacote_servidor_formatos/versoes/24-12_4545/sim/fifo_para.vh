// initial a empty file
