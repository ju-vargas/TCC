#!/bin/sh
# ==============================================================
# Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
# Tool Version Limit: 2026.06
# Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
# Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
# 
# ==============================================================
# The next line restarts using autoesl tclsh \
    exec /home/juliana/2026.1/Vitis/bin/vitis-run --mode hls --tcl run_sim.tcl
